<?php
/**
* COMPONENT FILE HEADER
**/
namespace G2\E\Chronoforms;
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
defined("GCORE_SITE") or die;
class Chronoforms extends \G2\A\E\Chronoforms\C\Manager {
	var $view = ['views' => ['site' => 'admin']];
}
?>